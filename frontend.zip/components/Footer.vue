<template >
  <div>
    <footer class="main-footer text-center bg-green-200">
      <strong><a href="https://vir-za.com">Frontend Footer</a>.</strong> All rights reserved.
    </footer>
  </div>
</template>
<script>
export default {

}
</script>

<style scoped>

</style>
