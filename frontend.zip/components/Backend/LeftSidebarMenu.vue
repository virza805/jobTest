<template>
  <div class="sidebar">
    <ul class="left_sidebar">
      <li class=" ">
        <nuxt-link to="/backend/showCategory"> Show Category Data</nuxt-link>
      </li>
      <li class=" ">
        <nuxt-link to="/backend/addCategory"> Add Category</nuxt-link>
      </li>
      <li class=" ">
        <nuxt-link to="/backend/showProduct"> Show Product Data</nuxt-link>
      </li>
      <li class=" ">
        <nuxt-link to="/backend/addProduct"> Add Product</nuxt-link>
      </li>
      <!-- <li class="  ">
        <a href="#" class="dropdown-btn active">Product Data &dArr;</a>
        <ul class="     dropdown-container">
          <li class=" ">
            <nuxt-link to="/backend/showProduct"> Show Product Data</nuxt-link>
          </li>
          <li class=" ">
            <nuxt-link to="/backend/addProduct"> Add Product</nuxt-link>
          </li>
        </ul>
      </li> -->
    </ul>
  </div>
</template>
