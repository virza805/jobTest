import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _1479e412 = () => interopDefault(import('..\\pages\\Backend\\index.vue' /* webpackChunkName: "pages/Backend/index" */))
const _4a6751b2 = () => interopDefault(import('..\\pages\\category.vue' /* webpackChunkName: "pages/category" */))
const _06f4bf87 = () => interopDefault(import('..\\pages\\productDetails.vue' /* webpackChunkName: "pages/productDetails" */))
const _3d93134e = () => interopDefault(import('..\\pages\\auth\\forgot-password.vue' /* webpackChunkName: "pages/auth/forgot-password" */))
const _16fabcbd = () => interopDefault(import('..\\pages\\auth\\login.vue' /* webpackChunkName: "pages/auth/login" */))
const _3a3a7202 = () => interopDefault(import('..\\pages\\auth\\register.vue' /* webpackChunkName: "pages/auth/register" */))
const _1af4f102 = () => interopDefault(import('..\\pages\\Backend\\addCategory.vue' /* webpackChunkName: "pages/Backend/addCategory" */))
const _08dea7fe = () => interopDefault(import('..\\pages\\Backend\\addProduct.vue' /* webpackChunkName: "pages/Backend/addProduct" */))
const _43285518 = () => interopDefault(import('..\\pages\\Backend\\editCategory.vue' /* webpackChunkName: "pages/Backend/editCategory" */))
const _664f4345 = () => interopDefault(import('..\\pages\\Backend\\editProduct.vue' /* webpackChunkName: "pages/Backend/editProduct" */))
const _174bed8b = () => interopDefault(import('..\\pages\\Backend\\showCategory.vue' /* webpackChunkName: "pages/Backend/showCategory" */))
const _f4255f1c = () => interopDefault(import('..\\pages\\Backend\\showProduct.vue' /* webpackChunkName: "pages/Backend/showProduct" */))
const _82117676 = () => interopDefault(import('..\\pages\\mixins\\form.js' /* webpackChunkName: "pages/mixins/form" */))
const _331f86ce = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/Backend",
    component: _1479e412,
    name: "Backend"
  }, {
    path: "/category",
    component: _4a6751b2,
    name: "category"
  }, {
    path: "/productDetails",
    component: _06f4bf87,
    name: "productDetails"
  }, {
    path: "/auth/forgot-password",
    component: _3d93134e,
    name: "auth-forgot-password"
  }, {
    path: "/auth/login",
    component: _16fabcbd,
    name: "auth-login"
  }, {
    path: "/auth/register",
    component: _3a3a7202,
    name: "auth-register"
  }, {
    path: "/Backend/addCategory",
    component: _1af4f102,
    name: "Backend-addCategory"
  }, {
    path: "/Backend/addProduct",
    component: _08dea7fe,
    name: "Backend-addProduct"
  }, {
    path: "/Backend/editCategory",
    component: _43285518,
    name: "Backend-editCategory"
  }, {
    path: "/Backend/editProduct",
    component: _664f4345,
    name: "Backend-editProduct"
  }, {
    path: "/Backend/showCategory",
    component: _174bed8b,
    name: "Backend-showCategory"
  }, {
    path: "/Backend/showProduct",
    component: _f4255f1c,
    name: "Backend-showProduct"
  }, {
    path: "/mixins/form",
    component: _82117676,
    name: "mixins-form"
  }, {
    path: "/",
    component: _331f86ce,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
