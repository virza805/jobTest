export { default as Footer } from '../..\\components\\Footer.vue'
export { default as Header } from '../..\\components\\Header.vue'
export { default as NuxtLogo } from '../..\\components\\NuxtLogo.vue'
export { default as SingleProductBox } from '../..\\components\\SingleProductBox.vue'
export { default as Toaster } from '../..\\components\\Toaster.vue'
export { default as Tutorial } from '../..\\components\\Tutorial.vue'
export { default as FormButton } from '../..\\components\\Form\\button.vue'
export { default as FormInput } from '../..\\components\\Form\\Input.vue'
export { default as FormTextarea } from '../..\\components\\Form\\Textarea.vue'
export { default as BackendClock } from '../..\\components\\Backend\\Clock.vue'
export { default as BackendDigitalClock } from '../..\\components\\Backend\\DigitalClock.vue'
export { default as BackendDropdown } from '../..\\components\\Backend\\dropdown.vue'
export { default as BackendFooter } from '../..\\components\\Backend\\Footer.vue'
export { default as BackendHeader } from '../..\\components\\Backend\\Header.vue'
export { default as BackendLeftSidebarMenu } from '../..\\components\\Backend\\LeftSidebarMenu.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
