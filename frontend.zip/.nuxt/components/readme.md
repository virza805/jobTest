# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<Footer>` | `<footer>` (components/Footer.vue)
- `<Header>` | `<header>` (components/Header.vue)
- `<NuxtLogo>` | `<nuxt-logo>` (components/NuxtLogo.vue)
- `<SingleProductBox>` | `<single-product-box>` (components/SingleProductBox.vue)
- `<Toaster>` | `<toaster>` (components/Toaster.vue)
- `<Tutorial>` | `<tutorial>` (components/Tutorial.vue)
- `<FormButton>` | `<form-button>` (components/Form/button.vue)
- `<FormInput>` | `<form-input>` (components/Form/Input.vue)
- `<FormTextarea>` | `<form-textarea>` (components/Form/Textarea.vue)
- `<BackendClock>` | `<backend-clock>` (components/Backend/Clock.vue)
- `<BackendDigitalClock>` | `<backend-digital-clock>` (components/Backend/DigitalClock.vue)
- `<BackendDropdown>` | `<backend-dropdown>` (components/Backend/dropdown.vue)
- `<BackendFooter>` | `<backend-footer>` (components/Backend/Footer.vue)
- `<BackendHeader>` | `<backend-header>` (components/Backend/Header.vue)
- `<BackendLeftSidebarMenu>` | `<backend-left-sidebar-menu>` (components/Backend/LeftSidebarMenu.vue)
